#include "os.h"
#include "vpn.h"

#ifdef _WIN32
#include "wintun.h"

int SCK_close(SCK fd){
    #ifdef _WIN32
    return closesocket(fd);
    #else
    return close(fd);
    #endif
}
int w_open(const char *filename, int flag){
   return _open(filename, flag);
}
int w_read(int file, unsigned char *buf, size_t count){
    return _read(file,buf,count);
}
int w_close(int file){
      return  _close(file);
}
ssize_t w_safe_read(const SOCKET fd, void *const buf_, size_t count, const int timeout)
{
    struct pollfd  pfd;
    char *buf    = (char *) buf_;
    ssize_t        readnb = (ssize_t) -1;

    while (readnb != 0 && count > (ssize_t) 0) {
        while ((readnb = recv(fd,buf,count,0)) < (ssize_t) 0) {
            if (errno == EAGAIN) {
                pfd.fd     = fd;
                pfd.events = POLLIN;

                if (WSAPoll(&pfd, (nfds_t) 1, timeout) <= 0) {
                    return (ssize_t) -1;
                }
            } else if (errno != EINTR || exit_signal_received) {
                printf("44.%d\n",WSAGetLastError());    //10053 - aborted due to timeout
                return (ssize_t) -1;
            }
        }
        printf("45.%d\n",WSAGetLastError());
        count -= readnb;
        buf += readnb;
    }
    return (ssize_t)(buf - (char *) buf_);;
}
ssize_t w_read_file(const int fd, void *const buf_, size_t count)
{
    //struct pollfd  pfd;
    unsigned char *buf    = (unsigned char *) buf_;
    ssize_t        readnb = (ssize_t) -1;
    while (readnb != 0 && count > (ssize_t) 0) {
        while ((readnb = w_read(fd, buf, count)) < (ssize_t) 0) 
        {
            //xy
        }
        
        count -= readnb;
        buf += readnb;
    }
    return (ssize_t)(buf - (unsigned char *) buf_);
}

ssize_t w_safe_write(const SOCKET fd, const void *const buf_, size_t count, const int timeout)
{
    struct pollfd pfd;
    const char *  buf = (const char *) buf_;
    ssize_t       written;

    while (count > (size_t) 0) {
        while ((written = send(fd, buf, count, 0)) < (ssize_t) 0) {
            if (errno == EAGAIN) {
                pfd.fd     = fd;
                pfd.events = POLLOUT;        
                printf("SEND. %d\n",WSAGetLastError());
                if (WSAPoll(&pfd, (nfds_t) 1, timeout) <= 0) {
                    return (ssize_t) -1;
                }
            } else if (errno != EINTR || exit_signal_received) {
                printf("SEND. %d\n",WSAGetLastError());
                return (ssize_t) -1;
            }
        }
        printf("8.%d\n",WSAGetLastError());
        buf += written;
        count -= written;
    }
    return (ssize_t)(buf - (const char *) buf_);
}

ssize_t w_safe_read_partial(const SOCKET fd, void *const buf_, const size_t max_count)
{
    char *const buf = (char *) buf_;
    ssize_t              readnb;

    while ((readnb = recv(fd, buf, max_count,0)) < (ssize_t) 0 && errno == EINTR &&
           !exit_signal_received)
        ;
        printf("10.%d\n",WSAGetLastError());
    return (ssize_t)readnb;
}

ssize_t w_safe_write_partial(const SOCKET fd, void *const buf_, const size_t max_count)
{
    char *const buf = (char *) buf_;
    ssize_t              writenb;

    while ((writenb = send(fd, buf, max_count,0)) < (ssize_t) 0 && errno == EINTR &&
           !exit_signal_received)
        ;
            printf("9.%d\n",WSAGetLastError());    
    return (ssize_t)writenb;
}

#endif




ssize_t safe_read(const SCK fd, void *const buf_, size_t count, const int timeout)
{   
    #ifdef _WIN32
    return w_safe_read(fd,buf_,count,timeout); //fd hodnotu porovnaj
    #else
    struct pollfd  pfd;
    unsigned char *buf    = (unsigned char *) buf_;
    ssize_t        readnb = (ssize_t) -1;
    while (readnb != 0 && count > (ssize_t) 0) {
        while ((readnb = read(fd, buf, count)) < (ssize_t) 0) 
        {
            if (errno == EAGAIN) {
                pfd.fd     = fd;
                pfd.events = POLLIN;

                if (poll(&pfd, (nfds_t) 1, timeout) <= 0) {
                    return (ssize_t) -1;
                }
            } else if (errno != EINTR || exit_signal_received) {
                return (ssize_t) -1;
            }
        }
        
        count -= readnb;
        buf += readnb;
    }
    return (ssize_t)(buf - (unsigned char *) buf_);
    #endif
}

ssize_t safe_write(const SCK fd, const void *const buf_, size_t count, const int timeout)
{
    #ifdef _WIN32
    ssize_t ret = w_safe_write(fd,buf_,count,timeout);
    return ret;
    #else
    struct pollfd pfd;
    const char *  buf = (const char *) buf_;
    ssize_t       written;

    while (count > (size_t) 0) {
        while ((written = write(fd, buf, count)) < (ssize_t) 0) {
            if (errno == EAGAIN) {
                pfd.fd     = fd;
                pfd.events = POLLOUT;
                if (poll(&pfd, (nfds_t) 1, timeout) <= 0) {
                    return (ssize_t) -1;
                }
            } else if (errno != EINTR || exit_signal_received) {
                return (ssize_t) -1;
            }
        }
        buf += written;
        count -= written;
    }
    return (ssize_t)(buf - (const char *) buf_);
    #endif
}

ssize_t safe_read_partial(const SCK fd, void *const buf_, const size_t max_count)
{   
    #ifdef _WIN32
    ssize_t ret = w_safe_read_partial(fd,buf_,max_count);
    return ret;
    #else
      unsigned char *const buf = (unsigned char *) buf_;
    ssize_t              readnb;

    while ((readnb = read(fd, buf, max_count)) < (ssize_t) 0 && errno == EINTR &&   //vracia pocet precitanych bajtov
           !exit_signal_received)
        ;
    return readnb;
    #endif
}

ssize_t safe_write_partial(const SCK fd, void *const buf_, const size_t max_count)
{   
    #ifdef _WIN32
    ssize_t ret = w_safe_write_partial(fd,buf_,max_count);
    return ret;
    #else
    unsigned char *const buf = (unsigned char *) buf_;
    ssize_t              writenb;

    while ((writenb = write(fd, buf, max_count)) < (ssize_t) 0 && errno == EINTR &&
           !exit_signal_received)
        ;
    return writenb;
    #endif
}

#ifdef __linux__
int tun_create(char if_name[IFNAMSIZ], const char *wanted_name)
{
    struct ifreq ifr;
    int          fd;
    int          err;

    fd = open("/dev/net/tun", O_RDWR);
    if (fd == -1) {
        fprintf(stderr, "tun module not present. See https://sk.tl/2RdReigK\n");
        return -1;
    }
    ifr.ifr_flags = IFF_TUN | IFF_NO_PI;
    snprintf(ifr.ifr_name, IFNAMSIZ, "%s", wanted_name == NULL ? "" : wanted_name);
    if (ioctl(fd, TUNSETIFF, &ifr) != 0) {
        err = errno;
        (void) close(fd);
        errno = err;
        return -1;
    }
    snprintf(if_name, IFNAMSIZ, "%s", ifr.ifr_name);

    return fd;
}
#elif defined(__APPLE__)
static int tun_create_by_id(char if_name[IFNAMSIZ], unsigned int id)
{
    struct ctl_info     ci;
    struct sockaddr_ctl sc;
    int                 err;
    int                 fd;

    if ((fd = socket(PF_SYSTEM, SOCK_DGRAM, SYSPROTO_CONTROL)) == -1) {
        return -1;
    }
    memset(&ci, 0, sizeof ci);
    snprintf(ci.ctl_name, sizeof ci.ctl_name, "%s", UTUN_CONTROL_NAME);
    if (ioctl(fd, CTLIOCGINFO, &ci)) {
        err = errno;
        (void) close(fd);
        errno = err;
        return -1;
    }
    memset(&sc, 0, sizeof sc);
    sc = (struct sockaddr_ctl){
        .sc_id      = ci.ctl_id,
        .sc_len     = sizeof sc,
        .sc_family  = AF_SYSTEM,
        .ss_sysaddr = AF_SYS_CONTROL,
        .sc_unit    = id + 1,
    };
    if (connect(fd, (struct sockaddr *) &sc, sizeof sc) != 0) {
        err = errno;
        (void) close(fd);
        errno = err;
        return -1;
    }
    snprintf(if_name, IFNAMSIZ, "utun%u", id);

    return fd;
}

int tun_create(char if_name[IFNAMSIZ], const char *wanted_name)
{
    unsigned int id;
    int          fd;

    if (wanted_name == NULL || *wanted_name == 0) {
        for (id = 0; id < 32; id++) {
            if ((fd = tun_create_by_id(if_name, id)) != -1) {
                return fd;
            }
        }
        return -1;
    }
    if (sscanf(wanted_name, "utun%u", &id) != 1) {
        errno = EINVAL;
        return -1;
    }
    return tun_create_by_id(if_name, id);
}
#elif defined(__OpenBSD__) || defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__)
int tun_create(char if_name[IFNAMSIZ], const char *wanted_name)
{
    char         path[64];
    unsigned int id;
    int          fd;

    if (wanted_name == NULL || *wanted_name == 0) {
        for (id = 0; id < 32; id++) {
            snprintf(if_name, IFNAMSIZ, "tun%u", id);
            snprintf(path, sizeof path, "/dev/%s", if_name);
            if ((fd = open(path, O_RDWR)) != -1) {
                return fd;
            }
        }
        return -1;
    }
    snprintf(if_name, IFNAMSIZ, "%s", wanted_name);
    snprintf(path, sizeof path, "/dev/%s", wanted_name);

    return open(path, O_RDWR);
}
#else
int tun_create(char if_name[IFNAMSIZ], const char *wanted_name)
{
    char path[64];

    if (wanted_name == NULL) {
        fprintf(stderr,
                "The tunnel device name must be specified on that platform "
                "(try 'tun0')\n");
        errno = EINVAL;
        return -1;
    }
    snprintf(if_name, IFNAMSIZ, "%s", wanted_name);
    snprintf(path, sizeof path, "/dev/%s", wanted_name);

    return open(path, O_RDWR);
}
#endif

#ifndef _WIN32
int tun_set_mtu(const char *if_name, int mtu)
{
    struct ifreq ifr;
    int          fd;

    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
        return -1;
    }
    ifr.ifr_mtu = mtu;
    snprintf(ifr.ifr_name, IFNAMSIZ, "%s", if_name);
    if (ioctl(fd, SIOCSIFMTU, &ifr) != 0) {
        close(fd);
        return -1;
    }
    return close(fd);
}
#endif

#if !defined(__APPLE__) && !defined(__OpenBSD__)
ssize_t tun_read(SCK fd, void *data, size_t size)
{   
    #ifdef _WIN32
    return w_safe_read_partial(fd,data,size);
    #else
    return safe_read_partial(fd, data, size);
    #endif
}

ssize_t tun_write(SCK fd, const void *data, size_t size)
{   
    #ifdef _WIN32
    return w_safe_write(fd, data, size, TIMEOUT);
    #else
    return safe_write(fd, data, size, TIMEOUT);
    #endif
}
#else
ssize_t tun_read(int fd, void *data, size_t size)
{
    ssize_t  ret;
    uint32_t family;

    struct iovec iov[2] = {
        {
            .iov_base = &family,
            .iov_len  = sizeof family,
        },
        {
            .iov_base = data,
            .iov_len  = size,
        },
    };

    ret = readv(fd, iov, 2);
    if (ret <= (ssize_t) 0) {
        return -1;
    }
    if (ret <= (ssize_t) sizeof family) {
        return 0;
    }
    return ret - sizeof family;
}

ssize_t tun_write(int fd, const void *data, size_t size)
{
    uint32_t family;
    ssize_t  ret;

    if (size < 20) {
        return 0;
    }
    switch (*(const uint8_t *) data >> 4) {
    case 4:
        family = htonl(AF_INET);
        break;
    case 6:
        family = htonl(AF_INET6);
        break;
    default:
        errno = EINVAL;
        return -1;
    }
    struct iovec iov[2] = {
        {
            .iov_base = &family,
            .iov_len  = sizeof family,
        },
        {
            .iov_base = (void *) data,
            .iov_len  = size,
        },
    };
    ret = writev(fd, iov, 2);
    if (ret <= (ssize_t) 0) {
        return ret;
    }
    if (ret <= (ssize_t) sizeof family) {
        return 0;
    }
    return ret - sizeof family;
}
#endif

static char *read_from_shell_command(char *result, size_t sizeof_result, const char *command)
{
    FILE *fp;
    char *pnt;

    #ifdef _WIN32
    if ((fp = _popen(command, "r")) == NULL) {
        return NULL;
    }
    sleep(1);
    #else
    if ((fp = popen(command, "r")) == NULL) {
        return NULL;
    }
    #endif
    if (fgets(result, (int) sizeof_result, fp) == NULL) {
        fprintf(stderr, "Command [%s] failed]\n", command);
        #ifdef _WIN32
            _pclose(fp);
        #else
            pclose(fp);
        #endif
        return NULL;
    }
    if ((pnt = strrchr(result, '\n')) != NULL) {
        *pnt = 0;
    }
        #ifdef _WIN32
            _pclose(fp);
        #else
         (void)   pclose(fp);
        #endif

        fprintf(stdout, "Command output: [%s] \n", result);
         if ((pnt = strrchr(result, 'O')) != NULL || (pnt = strrchr(result, 'T')) != NULL) {
            *pnt   = 0;
        }
    return  *result == 0 ? NULL : result;
}

const char *get_default_gw_ip(void)
{
    static char gw[64];
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__OpenBSD__) || \
    defined(__DragonFly__) || defined(__NetBSD__)
    return read_from_shell_command(
        gw, sizeof gw, "route -n get default 2>/dev/null|awk '/gateway:/{print $2;exit}'");
#elif defined(__linux__)
    return read_from_shell_command(gw, sizeof gw,
                                   "ip route show default 2>/dev/null|awk '/default/{print $3}'");
#elif defined(_WIN32)
    return read_from_shell_command(gw, sizeof gw,
                                   "route print 0.0.0.0 | findstr 0.0.0.0 | for /F \"tokens=3\" %i in ('more') do @echo %i");  
#else
    return NULL;
#endif
}

const char *get_default_ext_if_name(void)
{
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__OpenBSD__) || \
    defined(__DragonFly__) || defined(__NetBSD__)
    static char if_name[64];
    return read_from_shell_command(if_name, sizeof if_name,
                                   "route -n get default 2>/dev/null|awk "
                                   "'/interface:/{print $2;exit}'");
#elif defined(__linux__)
    static char if_name[64];
    return read_from_shell_command(if_name, sizeof if_name,
                                   "ip route show default 2>/dev/null|awk '/default/{print $5}'");
#elif defined(_WIN32)
    return "wtun0";                                                                    
#else
    return NULL;
#endif
}

int tcp_opts(SCK fd)
{
    int on = 1;
    #ifdef _WIN32
    #define SETSOCKOPT const char 
    #else
    #define SETSOCKOPT char
    #endif
    setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, (SETSOCKOPT *) &on, sizeof on);
    printf("55. %d\n",WSAGetLastError());
#ifdef TCP_QUICKACK
    (void) setsockopt(fd, IPPROTO_TCP, TCP_QUICKACK, (char *) &on, sizeof on);
#else
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (SETSOCKOPT *) &on, sizeof on);
    printf("66. %d\n",WSAGetLastError());
#endif
#ifdef TCP_CONGESTION
    (void) setsockopt(fd, IPPROTO_TCP, TCP_CONGESTION, OUTER_CONGESTION_CONTROL_ALG,
                      sizeof OUTER_CONGESTION_CONTROL_ALG - 1);
#endif
#if BUFFERBLOAT_CONTROL && defined(TCP_NOTSENT_LOWAT)
    (void) setsockopt(fd, IPPROTO_TCP, TCP_NOTSENT_LOWAT,
                      (char *) (unsigned int[]){ NOTSENT_LOWAT }, sizeof(unsigned int));
#endif
#ifdef TCP_USER_TIMEOUT
    (void) setsockopt(fd, IPPROTO_TCP, TCP_USER_TIMEOUT, (char *) (unsigned int[]){ TIMEOUT },
                      sizeof(unsigned int));
#endif
#ifdef SO_MARK
    (void) setsockopt(fd, SOL_SOCKET, SO_MARK, (char *) (unsigned int[]){ 42069U },
                      sizeof(unsigned int));
#endif
    return 0;
}

int shell_cmd(const char *substs[][2], const char *args_str, int silent)
{
    char * args[64];
    char   cmdbuf[4096];
    size_t args_i = 0, cmdbuf_i = 0, args_str_i, i;
    int    c, is_space = 1;

    errno = ENOSPC;
    for (args_str_i = 0; (c = args_str[args_str_i]) != 0; args_str_i++) {
        if (isspace((unsigned char) c)) {
            if (!is_space) {
                if (cmdbuf_i >= sizeof cmdbuf) {
                    return -1;
                }
                cmdbuf[cmdbuf_i++] = 0;
            }
            is_space = 1;
            continue;
        }
        if (is_space) {
            if (args_i >= sizeof args / sizeof args[0]) {
                return -1;
            }
            args[args_i++] = &cmdbuf[cmdbuf_i];
        }
        is_space = 0;
        for (i = 0; substs[i][0] != NULL; i++) {
            size_t pat_len = strlen(substs[i][0]), sub_len;
            if (!strncmp(substs[i][0], &args_str[args_str_i], pat_len)) {
                sub_len = strlen(substs[i][1]);
                if (sizeof cmdbuf - cmdbuf_i <= sub_len) {
                    return -1;
                }
                memcpy(&cmdbuf[cmdbuf_i], substs[i][1], sub_len);
                args_str_i += pat_len - 1;
                cmdbuf_i += sub_len;
                break;
            }
        }
        if (substs[i][0] == NULL) {
            if (cmdbuf_i >= sizeof cmdbuf) {
                return -1;
            }
            cmdbuf[cmdbuf_i++] = c;
        }
    }
    if (!is_space) {
        if (cmdbuf_i >= sizeof cmdbuf) {
            return -1;
        }
        cmdbuf[cmdbuf_i++] = 0;
    }
    if (args_i >= sizeof args / sizeof args[0] || args_i == 0) {
        return -1;
    }
    args[args_i] = NULL;
#ifndef _WIN32
    pid_t   child;
    int     exit_status;
    if ((child = fork()) == (pid_t) -1) {
        return -1;
    } else if (child == (pid_t) 0) {
        if (silent) {
            dup2(dup2(open("/dev/null", O_WRONLY), 2), 1);
        }
        execvp(args[0], args);
        _exit(1);
    } else if (waitpid(child, &exit_status, 0) == (pid_t) -1 || !WIFEXITED(exit_status)) {
        return -1;
    }
#else
    char command[4096]="";
    for(size_t j=0;j<args_i;j++){
    strcat(command, args[j]);
    strcat(command, " ");
    }

    if (silent) {
        strcat(command, " > NUL 2>&1");
    }

    char result[1024]="";
    if(read_from_shell_command(result, 1024, command)!= NULL){
        puts(result);
        return 0;   //-1
    }   
#endif
    return 0;
}

Cmds firewall_rules_cmds(int is_server)
{
    if (is_server) {
#ifdef __linux__
        static const char
            *set_cmds[] =
                { "sysctl net.ipv4.ip_forward=1", //ipv4 forwarding zapina
                  "ip addr add $LOCAL_TUN_IP peer $REMOTE_TUN_IP dev $IF_NAME", //priradenie ip
                  "ip -6 addr add $LOCAL_TUN_IP6 peer $REMOTE_TUN_IP6/96 dev $IF_NAME",
                  "ip link set dev $IF_NAME up", //zapnutie int
                  "iptables -t raw -I PREROUTING ! -i $IF_NAME -d $LOCAL_TUN_IP -m addrtype ! "
                  "--src-type LOCAL -j DROP", //blokuje vlastnu komunikaciu
                  "iptables -t nat -A POSTROUTING -o $EXT_IF_NAME -s $REMOTE_TUN_IP -j MASQUERADE", //nat server to tun
                  "iptables -t filter -A FORWARD -i $EXT_IF_NAME -o $IF_NAME -m state --state "
                  "RELATED,ESTABLISHED -j ACCEPT",
                  "iptables -t filter -A FORWARD -i $IF_NAME -o $EXT_IF_NAME -j ACCEPT",
                  NULL },
            *unset_cmds[] = {
                "iptables -t nat -D POSTROUTING -o $EXT_IF_NAME -s $REMOTE_TUN_IP -j MASQUERADE",
                "iptables -t filter -D FORWARD -i $EXT_IF_NAME -o $IF_NAME -m state --state "
                "RELATED,ESTABLISHED -j ACCEPT",
                "iptables -t filter -D FORWARD -i $IF_NAME -o $EXT_IF_NAME -j ACCEPT",
                "iptables -t raw -D PREROUTING ! -i $IF_NAME -d $LOCAL_TUN_IP -m addrtype ! "
                "--src-type LOCAL -j DROP",
                NULL
            };
#elif defined(_WIN32)
    static const char
        *set_cmds[] =
            { //"reg add HKLM\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters /v EnableTCPA /t REG_DWORD /d 0x1 /f",
              "netsh interface ipv4 add address $IF_NAME $LOCAL_TUN_IP 255.255.255.255",
              "netsh interface ipv6 add address $IF_NAME $LOCAL_TUN_IP6/96",
              "netsh advfirewall set allprofiles state off",
              "netsh interface ipv4 set subinterface wtun0 mtu=9000 store=persistent",  //default je 65 535 - mohlo by robit problem medzi serverom a klientom
              "netsh interface ipv4 set interface wtun0 forwarding=enabled", // Set-NetIPInterface -Forwarding disabled (pshell)
              "netsh interface set interface wtun0 admin=enable",
              "route add $REMOTE_TUN_IP mask 255.255.255.255 $LOCAL_TUN_IP",
              //"route add smerZoServera"
              //"route add smerDoServera"
             // "route add 0.0.0.0 mask 0.0.0.0 $EXT_GW_IP metric 20",  //defaultna ruta pre server
              //"route add $REMOTE_TUN_IP mask 255.255.255.255 $LOCAL_TUN_IP metric 5",
              //  "route add $EXT_IP mask 255.255.255.255 $EXT_GW_IP",
              NULL },
        *unset_cmds[] = { 
           // "netsh advfirewall set allprofiles state on",
           // "route -f",
           //"ipconfig /renew",
            NULL
        };
#elif defined(__APPLE__) || defined(__OpenBSD__) || defined(__FreeBSD__) || \
    defined(__DragonFly__) || defined(__NetBSD__)
        static const char *set_cmds[] =
            { "sysctl -w net.inet.ip.forwarding=1",
              "ifconfig $IF_NAME $LOCAL_TUN_IP $REMOTE_TUN_IP up",
              "ifconfig $IF_NAME inet6 $LOCAL_TUN_IP6 $REMOTE_TUN_IP6 prefixlen 128 up", NULL },
                          *unset_cmds[] = { NULL, NULL };
#else
        static const char *const *set_cmds = NULL, *const *unset_cmds = NULL;
#endif
        return (Cmds){ set_cmds, unset_cmds };
    } else {
#if defined(__APPLE__) || defined(__OpenBSD__) || defined(__FreeBSD__) || \
    defined(__DragonFly__) || defined(__NetBSD__)
        static const char *set_cmds[] =
            { "ifconfig $IF_NAME $LOCAL_TUN_IP $REMOTE_TUN_IP up",
              "ifconfig $IF_NAME inet6 $LOCAL_TUN_IP6 $REMOTE_TUN_IP6 prefixlen 128 up",
#ifndef NO_DEFAULT_ROUTES
              "route add $EXT_IP $EXT_GW_IP",
              "route add 0/1 $REMOTE_TUN_IP",
              "route add 128/1 $REMOTE_TUN_IP",
              "route add -inet6 -blackhole 0000::/1 $REMOTE_TUN_IP6",
              "route add -inet6 -blackhole 8000::/1 $REMOTE_TUN_IP6",
#endif
              NULL },
                          *unset_cmds[] = {
#ifndef NO_DEFAULT_ROUTES
                              "route delete $EXT_IP",
                              "route delete 0/1",
                              "route delete 128/1",
                              "route delete -inet6 0000::/1",
                              "route delete -inet6 8000::/1",
#endif
                              NULL
                          };
#elif defined(__linux__)
        static const char
            *set_cmds[] =
                { "sysctl net.ipv4.tcp_congestion_control=bbr",
                  "ip link set dev $IF_NAME up",
                  "iptables -t raw -I PREROUTING ! -i $IF_NAME -d $LOCAL_TUN_IP -m addrtype ! "
                  "--src-type LOCAL -j DROP",
                  "ip addr add $LOCAL_TUN_IP peer $REMOTE_TUN_IP dev $IF_NAME",
                  "ip -6 addr add $LOCAL_TUN_IP6 peer $REMOTE_TUN_IP6/96 dev $IF_NAME",
#ifndef NO_DEFAULT_ROUTES
                  "ip route add default dev $IF_NAME table 42069",
                  "ip -6 route add default dev $IF_NAME table 42069",
                  "ip rule add not fwmark 42069 table 42069",
                  "ip -6 rule add not fwmark 42069 table 42069",
                  "ip rule add table main suppress_prefixlength 0",
                  "ip -6 rule add table main suppress_prefixlength 0",
#endif
                  NULL },
            *unset_cmds[] = {
#ifndef NO_DEFAULT_ROUTES
                "ip rule delete table 42069",
                "ip -6 rule delete table 42069",
                "ip rule delete table main suppress_prefixlength 0",
                "ip -6 rule delete table main suppress_prefixlength 0",
#endif
                "iptables -t raw -D PREROUTING ! -i $IF_NAME -d $LOCAL_TUN_IP -m addrtype ! "
                "--src-type LOCAL -j DROP",
                NULL
            };
#elif defined(_WIN32)
        static const char
    *set_cmds[] =
        { "netsh advfirewall set allprofiles state off",
          "netsh interface ipv4 set subinterface \"wtun0\" mtu=9000 store=persistent",
          "netsh interface ipv4 set interface $IF_NAME forwarding=enabled",
          "netsh interface ipv4 add address $IF_NAME $LOCAL_TUN_IP 255.255.255.255",
          "netsh interface ipv6 add address $IF_NAME $LOCAL_TUN_IP6/96",
          "netsh interface set interface $IF_NAME admin=enable",
          "route add $EXT_IP mask 255.255.255.255 $EXT_GW_IP",
          "route delete 0.0.0.0",
          "route add 0.0.0.0 mask 0.0.0.0 $LOCAL_TUN_IP",
          //"route add $REMOTE_TUN_IP mask 255.255.255.255 $LOCAL_TUN_IP", //nema vyznam ked vsetko posielam na tun 
          //"Install-Module -Name TcpConGestionControl -RequiredVersion 1.0.0",
        //"Enable-NetTcpCongestionControl -Name bbr", //ps scripty pre tcpcongestion (prve 3)
        //Disable-NetTcpCongestionControl -Name bbr,
        #ifndef NO_DEFAULT_ROUTES
        // "route add 0.0.0.0 mask 0.0.0.0 $EXT_GW_IP",  //alebo local_tun_ip
        // "route add $EXT_IP mask 255.255.255.255 $EXT_GW_IP",
         //"route add ::/0 $LOCAL_TUN_IP6 metric 3",
        #endif
          NULL },
    *unset_cmds[] = {
       //   "netsh advfirewall set allprofiles state on",
        //  "route -f",
         // "ipconfig /renew",
        NULL
    };     
#else
        static const char *const *set_cmds = NULL, *const *unset_cmds = NULL;
#endif
        return (Cmds){ set_cmds, unset_cmds };
    }
}
