#include "vpn.h"
#include "charm.h"
#include "os.h"

#ifdef _WIN32
static WINTUN_CREATE_ADAPTER_FUNC *WintunCreateAdapter;
static WINTUN_CLOSE_ADAPTER_FUNC *WintunCloseAdapter;
static WINTUN_DELETE_DRIVER_FUNC *WintunDeleteDriver;
static WINTUN_START_SESSION_FUNC *WintunStartSession;
static WINTUN_END_SESSION_FUNC *WintunEndSession;
static WINTUN_GET_ADAPTER_LUID_FUNC *WintunGetAdapterLUID; 
static WINTUN_RECEIVE_PACKET_FUNC *WintunReceivePacket;
static WINTUN_RELEASE_RECEIVE_PACKET_FUNC *WintunReleaseReceivePacket;
static WINTUN_ALLOCATE_SEND_PACKET_FUNC *WintunAllocateSendPacket;
static WINTUN_SEND_PACKET_FUNC *WintunSendPacket;
static WINTUN_GET_READ_WAIT_EVENT_FUNC *WintunGetReadWaitEvent;

#endif

static const int POLLFD_TUN = 0, POLLFD_LISTENER = 1, POLLFD_CLIENT = 2, POLLFD_COUNT = 3;

typedef struct __attribute__((aligned(16))) Buf_ {
#if TAG_LEN < 16 - 2
    unsigned char _pad[16 - TAG_LEN - 2];
#endif
    unsigned char len[2];
    unsigned char tag[TAG_LEN];
    unsigned char data[MAX_PACKET_LEN];
    size_t        pos;
} Buf;

int is_all_zeros(unsigned char* data, int data_size) {
    for (int i = 0; i < data_size; i++) {
        if (data[i] != 0) {
            return 0;
        }
    }
    return 1;
}

void print_packet(unsigned char *packet, int packet_size) {
    int c=0,f=0;
    if(!is_all_zeros(packet,packet_size)){
        for (int i = 0; i < packet_size; i++) {
            if(packet[i] == 0)  {
                c++;}
            else c=0; 
            if(c>=16)break;
            printf("%02X", packet[i]);
            f++;
            if ((i+1) % 16 == 0) {
                printf("\n");
            }
        }
    }
    printf("\n");
    printf("%d\n", f);
}

typedef struct Context_ {
    const char *  wanted_if_name;
    const char *  local_tun_ip;
    const char *  remote_tun_ip;
    const char *  local_tun_ip6;
    const char *  remote_tun_ip6;
    const char *  server_ip_or_name;
    const char *  server_port;
    const char *  ext_if_name;
    const char *  wanted_ext_gw_ip;
    char          client_ip[NI_MAXHOST];
    char          ext_gw_ip[64];
    char          server_ip[64];
    char          if_name[IFNAMSIZ];
    int           is_server;
    int           congestion;
    int           firewall_rules_set;
    Buf           client_buf;
    struct pollfd fds[3];
    uint32_t      uc_kx_st[12];
    uint32_t      uc_st[2][12];
    SCK           tun_fd;
    SCK           client_fd;
    SCK           listen_fd;
#ifdef _WIN32
    WINTUN_SESSION_HANDLE session;
    WINTUN_ADAPTER_HANDLE adapter;
    HMODULE wtunModule;  
#endif

} Context;

volatile sig_atomic_t exit_signal_received;

static void signal_handler(int sig)
{
    signal(sig, SIG_DFL);
    exit_signal_received = 1;
}
#ifdef _WIN32

void w_cleanUp(Context *context){
    WSACleanup();
    WintunEndSession(context->session);
    WintunCloseAdapter(context->adapter);
    FreeLibrary(context->wtunModule);
}

int wtunInit(Context *context){
 HMODULE Wintun = LoadLibraryExW(L"wintun.dll", NULL, LOAD_LIBRARY_SEARCH_APPLICATION_DIR | LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!Wintun)
        return -1;
#define X(Name) ((*(FARPROC *)&Name = GetProcAddress(Wintun, #Name)) == NULL)
    if (X(WintunCreateAdapter) || X(WintunCloseAdapter) || X(WintunDeleteDriver) || 
        X(WintunStartSession) || X(WintunEndSession) || X(WintunGetAdapterLUID)|| 
        X(WintunReceivePacket) || X(WintunReleaseReceivePacket) ||
        X(WintunGetReadWaitEvent) || X(WintunAllocateSendPacket) ||
         X(WintunSendPacket)/*|| X(WintunOpenAdapter) ||
        X(WintunGetRunningDriverVersion)  || X(WintunSetLogger) || 
        */)
#undef X
    {
        DWORD LastError = GetLastError();
        FreeLibrary(Wintun);
        SetLastError(LastError);
        return -1;
    }
//HMODULE Wintun = InitializeWintun();
    if (!Wintun){
        puts("Failed to initialize Wintun");
        FreeLibrary(Wintun);
        return -1;        
    }
    else{    
        puts("Wintun library loaded");
    }
    
    GUID MyGuid = { 0xdeadbabe, 0xcafe, 0xbeef, { 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef } }; //moze byt null
    context->adapter = WintunCreateAdapter(L"wtun0", L"Wintun", &MyGuid);
    if (!context->adapter){
        puts("Failed to create Wintun adapter");
        return -1;
    }
    snprintf(context->if_name, IFNAMSIZ, "%s", "wtun0");
    MIB_UNICASTIPADDRESS_ROW AddressRow;
    InitializeUnicastIpAddressEntry(&AddressRow);
    WintunGetAdapterLUID(context->adapter, &AddressRow.InterfaceLuid);
    AddressRow.Address.Ipv4.sin_family = AF_INET;
    AddressRow.Address.Ipv4.sin_addr.S_un.S_addr =  inet_addr(context->local_tun_ip); 
    AddressRow.OnLinkPrefixLength = 24; /* This is a /24 network */
    //inet_pton(AF_INET6, context.local_tun_ip6, AddressRow.Address.Ipv6.sin6_addr);
    //AddressRow.Address.Ipv6.sin6_family = AF_INET6;
    AddressRow.DadState = IpDadStatePreferred;
    CreateUnicastIpAddressEntry(&AddressRow);
    context->session = WintunStartSession(context->adapter, 0x400000);
    context->wtunModule = Wintun;
    puts("wtuninit ok");
    return 0;
}

int tun_reader(Context *context, unsigned char *outgoingData){ 
    BYTE *Packet;
    DWORD size;
    while(1){
        Packet = WintunReceivePacket(context->session, &size);
        if (Packet){   
        //can be implemented another logic here
        memcpy(outgoingData, Packet, size);
        WintunReleaseReceivePacket(context->session, Packet);
        return size;      //pocet bitov
        }else if (GetLastError() == ERROR_NO_MORE_ITEMS){
        WaitForSingleObject(WintunGetReadWaitEvent(context->session), INFINITE);
            }
            else{
            printf("Tun reader error: %ld\n",GetLastError());
            return -1;
            }
    }
}

int tun_writer(Context *context, BYTE *PacketData, ssize_t PacketDataSize){     //vieme posielaat len raw data bez informacii o smerovani ked nastavime smerovanie na tunel
   BYTE *OutgoingPacket = WintunAllocateSendPacket(context->session, PacketDataSize);
    if (OutgoingPacket){
        memset(OutgoingPacket, 0, PacketDataSize);     //vycistenie
        //OutgoingPacket[0] = 0x45;                           //ip protokol
        //OutgoingPacket[1] = 0x00;                           //DSF
        //*(USHORT *)&OutgoingPacket[2] = htons(PacketDataSize + 20); //dlzka
        //OutgoingPacket[5] = 0x00;                           //Identification 5+6 82
        //OutgoingPacket[6] = 0x00;                           //identif.2 24
        //OutgoingPacket[7] = 0x40;                           //flag dont fragment
        //OutgoingPacket[8] = 0x80;                           //128 time to live
        //OutgoingPacket[9] = 0x11;                           //prot udp
        //OutgoingPacket[10] = 0x00;                          //healthccheckoff 10+11
        //OutgoingPacket[11] = 0x00;
        //*(ULONG *)&OutgoingPacket[12] = inet_addr(context->local_tun_ip); /* source ip */
        //*(ULONG *)&OutgoingPacket[16] = htonl((10 << 24) | (8 << 16) | (2 << 8) | (1 << 0));//inet_addr(context->remote_tun_ip); /* destination ip */ 
        memcpy(OutgoingPacket, PacketData, PacketDataSize); 
        WintunSendPacket(context->session, OutgoingPacket);
        return 0;
    }else{
    printf("Tun writer error: %ld\n",GetLastError());
    }
    return -1;
}


#endif 

static int firewall_rules(Context *context, int set, int silent)
{
    const char *       substs[][2] = { { "$LOCAL_TUN_IP6", context->local_tun_ip6 },
                                { "$REMOTE_TUN_IP6", context->remote_tun_ip6 },
                                { "$LOCAL_TUN_IP", context->local_tun_ip },
                                { "$REMOTE_TUN_IP", context->remote_tun_ip },
                                { "$EXT_IP", context->server_ip },
                                { "$EXT_PORT", context->server_port },
                                { "$EXT_IF_NAME", context->ext_if_name },
                                { "$EXT_GW_IP", context->ext_gw_ip },
                                { "$IF_NAME", context->if_name },
                                { NULL, NULL } };
    const char *const *cmds;
    size_t             i;

    if (context->firewall_rules_set == set) {
        return 0;
    }
    if ((cmds = (set ? firewall_rules_cmds(context->is_server).set
                     : firewall_rules_cmds(context->is_server).unset)) == NULL) {
        fprintf(stderr,
                "Routing commands for that operating system have not been "
                "added yet.\n");
        puts("fwr cmd ok");
        return 0;
    }
    for (i = 0; cmds[i] != NULL; i++) {
        if (shell_cmd(substs, cmds[i], silent) != 0) {
            fprintf(stderr, "Unable to run [%s]: [%s]\n", cmds[i], strerror(errno));
            return -1;
        }
    }
    context->firewall_rules_set = set;
    puts("firewall_rules ok");
    return 0;
}

static int server_key_exchange(Context *context, const SCK client_fd)
{
    uint32_t st[12];
    uint8_t  pkt1[32 + 8 + 32], pkt2[32 + 32];
    uint8_t  h[32];
    uint8_t  k[32];
    uint8_t  iv[16] = { 0 };
    uint64_t ts, now;

    memcpy(st, context->uc_kx_st, sizeof st);
    errno = EACCES; //clien_fd kukni
    if (safe_read(client_fd, pkt1, sizeof pkt1, ACCEPT_TIMEOUT) != sizeof pkt1) {
        return -1;
    }
    uc_hash(st, h, pkt1, 32 + 8);
    if (memcmp(h, pkt1 + 32 + 8, 32) != 0) {
        return -1;
    }
    memcpy(&ts, pkt1 + 32, 8);
    ts  = endian_swap64(ts);
    now = time(NULL);
    if ((ts > now && ts - now > TS_TOLERANCE) || (now > ts && now - ts > TS_TOLERANCE)) {
        fprintf(stderr,
                "Clock difference is too large: %" PRIu64 " (client) vs %" PRIu64 " (server)\n", ts,
                now);
        return -1;
    }
    uc_randombytes_buf(pkt2, 32);
    uc_hash(st, pkt2 + 32, pkt2, 32);
    if (safe_write_partial(client_fd, pkt2, sizeof pkt2) != sizeof pkt2) {
        return -1;
    }
    uc_hash(st, k, NULL, 0);
    iv[0] = context->is_server;
    uc_state_init(context->uc_st[0], k, iv);
    iv[0] ^= 1;
    uc_state_init(context->uc_st[1], k, iv);

    return 0;
}


static SCK tcp_accept(Context *context, SCK listen_fd)
{
    char                    client_ip[NI_MAXHOST] = { 0 };
    struct sockaddr_storage client_ss ={0}; //inicializoval som ho
 
    socklen_t               client_ss_len = sizeof(client_ss);
    SCK                     client_fd;
    int                     err;

    if ((client_fd = accept(listen_fd, (struct sockaddr*)&client_ss, &client_ss_len)) == SCKERR) { //bolo <0, return -1
        //check return values
        printf("Accept: %d\n",WSAGetLastError());
        return INVSCK;
    }

    if (client_ss_len <= (socklen_t) 0U) {
        (void) SCK_close(client_fd);
        errno = EINTR;
        return INVSCK;
    }
    if (tcp_opts(client_fd) != 0) {
        err = errno;   //mala by byt nula
        (void) SCK_close(client_fd);
        errno = err;
        return INVSCK;
    }
    err = getnameinfo((const struct sockaddr *) (const void *) &client_ss, client_ss_len, client_ip,
                sizeof client_ip, NULL, 0, NI_NUMERICHOST | NI_NUMERICSERV);
                //0ok 
    printf("Connection attempt from [%s]\n", client_ip);
    context->congestion = 0;
    #ifdef _WIN32
    unsigned long non_blocking = 1;
    err= ioctlsocket(client_fd, FIONBIO, (unsigned long *) &non_blocking); //0 ok
     printf("IOCTL: %d\n",WSAGetLastError());
    #else
    err= fcntl(client_fd, F_SETFL, fcntl(client_fd, F_GETFL, 0) | O_NONBLOCK); //0 ok
    #endif
    if (context->client_fd != INVSCK &&
        memcmp(context->client_ip, client_ip, sizeof context->client_ip) != 0) {
        fprintf(stderr, "Closing: a session from [%s] is already active\n", context->client_ip);
        (void) SCK_close(client_fd);
        errno = EBUSY;
        return INVSCK;
    }
    if (server_key_exchange(context, client_fd) != 0) {
        fprintf(stderr, "Authentication failed\n");
        (void) SCK_close(client_fd);
        errno = EACCES;
        return INVSCK;
    }
    memcpy(context->client_ip, client_ip, sizeof context->client_ip);
    return client_fd;
}

static SCK tcp_client(const char *address, const char *port)
{
    struct addrinfo hints, *res;
    int             eai;
    int             err;    
    SCK             client_fd;

    printf("Connecting to %s:%s...\n", address, port);
    memset(&hints, 0, sizeof hints);
    hints.ai_flags    = 0;
    hints.ai_family   = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_addr     = NULL;
    if ((eai = getaddrinfo(address, port, &hints, &res)) != 0 ||
        (res->ai_family != AF_INET && res->ai_family != AF_INET6)) {
        fprintf(stderr, "Unable to create the client socket: [%s]\n", gai_strerror(eai));
        errno = EINVAL;
        return INVSCK;
    }

    if ((client_fd = socket(res->ai_family, SOCK_STREAM, IPPROTO_TCP)) == INVSCK ||
        tcp_opts(client_fd) != 0 ||
        connect(client_fd, (const struct sockaddr *) res->ai_addr, res->ai_addrlen) != 0) {//&pred res
        freeaddrinfo(res);
        err = errno;
        printf("30.%d\n",WSAGetLastError());
        (void) SCK_close(client_fd);
        errno = err;
        return INVSCK;
    }
    printf("FYI. %d\n",WSAGetLastError());
    freeaddrinfo(res);
    return client_fd;
}

static SCK tcp_listener(const char *address, const char *port)
{
    struct addrinfo hints, *res;
    int             eai, err;
    int             backlog = 1;
    SCK             listen_fd;


    memset(&hints, 0, sizeof hints);
    hints.ai_flags    = AI_PASSIVE;
    hints.ai_family   = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_addr     = NULL;
#if defined(__OpenBSD__) || defined(__DragonFly__)
    if (address == NULL) {
        hints.ai_family = AF_INET;
    }
#endif
    if ((eai = getaddrinfo(address, port, &hints, &res)) != 0 ||
        (res->ai_family != AF_INET && res->ai_family != AF_INET6)) {
        fprintf(stderr, "Unable to create the listening socket: [%s]\n", gai_strerror(eai));
        errno = EINVAL;
        return INVSCK;
    }
    if ((listen_fd = socket(res->ai_family, SOCK_STREAM, IPPROTO_TCP)) == INVSCK ||
        setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, (char *) (int[]){ 1 }, sizeof(int)) != 0) {
        err = errno;
        printf("25.%d\n",WSAGetLastError());
        (void) SCK_close(listen_fd);
        freeaddrinfo(res);
        errno = err;
        return INVSCK;
    }
#if defined(IPPROTO_IPV6) && defined(IPV6_V6ONLY)
    (void) setsockopt(listen_fd, IPPROTO_IPV6, IPV6_V6ONLY, (char *) (int[]){ 0 }, sizeof(int));
#endif
#ifdef TCP_DEFER_ACCEPT
    (void) setsockopt(listen_fd, SOL_TCP, TCP_DEFER_ACCEPT,
                      (char *) (int[]){ ACCEPT_TIMEOUT / 1000 }, sizeof(int));
#endif
    printf("Listening to %s:%s\n", address == NULL ? "*" : address, port);
    if (bind(listen_fd, (struct sockaddr *) res->ai_addr, (socklen_t) res->ai_addrlen) != 0 ||  //kukni ci pripisuje dobru add
        listen(listen_fd, backlog) != 0) {
        printf("Bind and Listen %d\n",WSAGetLastError());
        freeaddrinfo(res);
        return INVSCK;
    }
    printf("Bind and Listen %d\n",WSAGetLastError());
    freeaddrinfo(res);

    return listen_fd;
}

static void client_disconnect(Context *context)
{
    if (context->client_fd == INVSCK) {
        return;
    }
    (void) SCK_close(context->client_fd);
    context->client_fd          = -1;
    context->fds[POLLFD_CLIENT] = (struct pollfd){ .fd = -1, .events = 0 };
    memset(context->uc_st, 0, sizeof context->uc_st);
}

static int client_key_exchange(Context *context)
{
    uint32_t st[12];
    uint8_t  pkt1[32 + 8 + 32], pkt2[32 + 32];
    uint8_t  h[32];
    uint8_t  k[32];
    uint8_t  iv[16] = { 0 };
    uint64_t now;
    memcpy(st, context->uc_kx_st, sizeof st);
    uc_randombytes_buf(pkt1, 32);
    now = endian_swap64(time(NULL));
    memcpy(pkt1 + 32, &now, 8);
    uc_hash(st, pkt1 + 32 + 8, pkt1, 32 + 8);
    if (safe_write(context->client_fd, pkt1, sizeof pkt1, TIMEOUT) != sizeof pkt1) {
        return -1;
    }
    errno = EACCES; //client_fd kukni
    sleep(1);
    if (safe_read(context->client_fd, pkt2, sizeof pkt2, TIMEOUT) != sizeof pkt2) {
        return -1;
    }
    uc_hash(st, h, pkt2, 32);
    if (memcmp(h, pkt2 + 32, 32) != 0) {
        return -1;
    }
    uc_hash(st, k, NULL, 0);
    iv[0] = context->is_server;
    uc_state_init(context->uc_st[0], k, iv);
    iv[0] ^= 1;
    uc_state_init(context->uc_st[1], k, iv);

    return 0;
}

static int client_connect(Context *context)
{
    const char *ext_gw_ip = NULL;

    context->client_buf.pos = 0;
    memset(context->client_buf.data, 0, sizeof context->client_buf.data);
#ifndef NO_DEFAULT_ROUTES
    if (context->wanted_ext_gw_ip == NULL && (ext_gw_ip = get_default_gw_ip()) != NULL &&
        strcmp(ext_gw_ip, context->ext_gw_ip) != 0) {
        printf("Gateway changed from [%s] to [%s]\n", context->ext_gw_ip, ext_gw_ip);
        firewall_rules(context, 0, 0);
        snprintf(context->ext_gw_ip, sizeof context->ext_gw_ip, "%s", ext_gw_ip);
        firewall_rules(context, 1, 0);
    }
#endif
    printf("5.%d\n",WSAGetLastError());
    memset(context->uc_st, 0, sizeof context->uc_st);
    context->uc_st[context->is_server][0] ^= 1;
    context->client_fd = tcp_client(context->server_ip, context->server_port);
    printf("7.%d\n",WSAGetLastError());
    if (context->client_fd == INVSCK) {
        perror("Client connection failed");
        return -1;
    }
    #ifdef _WIN32
    unsigned long non_blocking = 1;
    ioctlsocket(context->client_fd, FIONBIO, (unsigned long *) &non_blocking);
    printf("IOCTL2. %d\n",WSAGetLastError());
    #else
    fcntl(context->client_fd, F_SETFL, fcntl(context->client_fd, F_GETFL, 0) | O_NONBLOCK);
    #endif
    context->congestion = 0;
    if (client_key_exchange(context) != 0) {
        fprintf(stderr, "Authentication failed\n");
        client_disconnect(context);
        sleep(1);
        return -1;
    }
    firewall_rules(context, 1, 0);
    context->fds[POLLFD_CLIENT] =
        (struct pollfd){ .fd = context->client_fd, .events = POLLIN, .revents = 0 };
    puts("Connected");

    return 0;
}

static int client_reconnect(Context *context)
{
    unsigned int i;

    client_disconnect(context);
    if (context->is_server) {
        return 0;
    }
    for (i = 0; exit_signal_received == 0 && i < RECONNECT_ATTEMPTS; i++) {
        puts("Trying to reconnect");
        sleep(i > 3 ? 3 : i);
        if (client_connect(context) == 0) {
            return 0;
        }
    }
    return -1;
}

static int event_loop(Context *context)
{
    struct pollfd *const fds = context->fds;
    Buf                  tun_buf;
    Buf *                client_buf = &context->client_buf;
    ssize_t              len;
    int                  found_fds;
    SCK                  new_client_fd;

    if (exit_signal_received != 0) {
        return -2;
    }

    #ifdef _WIN32
     if ((found_fds = WSAPoll(fds, POLLFD_COUNT, 1500)) == -1) {
        return errno == EINTR ? 0 : -1;
    }
    #else
    if ((found_fds = poll(fds, POLLFD_COUNT, 1500)) == -1) {
        return errno == EINTR ? 0 : -1;
    }
    #endif

    if (fds[POLLFD_LISTENER].revents & POLLIN) {    //len server nema null ak ma klienta uz
        new_client_fd = tcp_accept(context, context->listen_fd);
        if (new_client_fd == INVSCK) {
            perror("Accepting a new client failed");
            return 0;
        }
        if (context->client_fd != INVSCK) { //len server ma null
            (void) SCK_close(context->client_fd);
            sleep(1);
        }
        context->client_fd = new_client_fd;
        client_buf->pos    = 0;
        memset(client_buf->data, 0, sizeof client_buf->data);
        puts("Session established");
        fds[POLLFD_CLIENT] = (struct pollfd){ .fd = context->client_fd, .events = POLLIN };
    }
        
        int readAccess = 1;  //ci ma tun data na citanie
        #ifndef _WIN32
        readAccess= fds[POLLFD_TUN].revents & POLLIN;   //treba na linuxe skontrolovat
        #endif         
    if (readAccess) {
            #ifdef _WIN32
            len = tun_reader(context, tun_buf.data);
            #else
            len = tun_read(context->tun_fd, tun_buf.data, sizeof tun_buf.data); //precitas, ulozis, vratisa velkost
            #endif 
            if (len <= 0) { 
                perror("tun_read");
                return -1;
            }

        if ((fds[POLLFD_TUN].revents & POLLERR) || (fds[POLLFD_TUN].revents & POLLHUP)) {
            puts("HUP (tun)");
            return -1;
        }
        #ifdef BUFFERBLOAT_CONTROL  //zahltenie overi
        if (context->congestion) {
            context->congestion = 0;
            return 0;
        }
        #endif

        if (context->client_fd != INVSCK) { //zapis do socketu klienta - sifrovane ak uz je pripojena druha strana
            unsigned char tag_full[16];
            ssize_t       writenb;
            uint16_t      binlen = endian_swap16((uint16_t) len);

            memcpy(tun_buf.len, &binlen, 2);
            uc_encrypt(context->uc_st[0], tun_buf.data, len, tag_full);
            memcpy(tun_buf.tag, tag_full, TAG_LEN);

            writenb = safe_write_partial(context->client_fd, tun_buf.len, 2U + TAG_LEN + len);  //zasifrovane do soketu druhej strany
            printf("20.%d\n",WSAGetLastError());
            if (writenb < (ssize_t) 0) {
                context->congestion = 1;
                writenb             = (ssize_t) 0;
            }
            if (writenb != (ssize_t)(2U + TAG_LEN + len)) {
                writenb = safe_write(context->client_fd, tun_buf.len + writenb,
                                     2U + TAG_LEN + len - writenb, TIMEOUT);
            }
            if (writenb < (ssize_t) 0) {
                perror("Unable to write data to the TCP socket");
                        printf("12.%d\n",WSAGetLastError());
                return client_reconnect(context);
            }
        }
    }

    if ((fds[POLLFD_CLIENT].revents & POLLERR) || (fds[POLLFD_CLIENT].revents & POLLHUP)) {
        puts("Client disconnected");
        return client_reconnect(context);
    }
    if (fds[POLLFD_CLIENT].revents & POLLIN) {
        uint16_t binlen;
        size_t   len_with_header;
        ssize_t  readnb;

        if ((readnb = safe_read_partial(context->client_fd, client_buf->len + client_buf->pos,
                                        2 + TAG_LEN + MAX_PACKET_LEN - client_buf->pos)) <= 0) {    //precita data zo soketu klienta
            puts("Client disconnected");
            return client_reconnect(context);
        }
        client_buf->pos += readnb;
        while (client_buf->pos >= 2 + TAG_LEN) {
            memcpy(&binlen, client_buf->len, 2);
            len = (ssize_t) endian_swap16(binlen);          
            if (client_buf->pos < (len_with_header = 2 + TAG_LEN + (size_t) len)) { //overi velkost dat po sifrovani
                break;
            }
            
            if (uc_decrypt(context->uc_st[1], client_buf->data, len, client_buf->tag, TAG_LEN) !=
                0) {
                fprintf(stderr, "Corrupted stream\n");  //desifruje
                sleep(1);
                return client_reconnect(context);
            }
            #ifdef _WIN32
            if (tun_writer(context, client_buf->data, len) != 0) { //zapis do tunelu, ale preco nikto nevie
                perror("tun_writer");
            }
            #else
            if (tun_write(context->tun_fd, client_buf->data, len) != len) { // posle tunelom
                perror("tun_write");
            }
            #endif
            if (2 + TAG_LEN + MAX_PACKET_LEN != len_with_header) {  //posun buffera
                unsigned char *rbuf      = client_buf->len;         //posun buffera
                size_t         remaining = client_buf->pos - len_with_header;   //posun buffera
                memmove(rbuf, rbuf + len_with_header, remaining);   //posun buffera
            }
            client_buf->pos -= len_with_header;     //posun buffera
        }
    }
    return 0;
}

static int doit(Context *context)
{
    context->client_fd = context->listen_fd = INVSCK;
    memset(context->fds, 0, sizeof *context->fds);
    context->fds[POLLFD_TUN] =
        (struct pollfd){ .fd = context->tun_fd, .events = POLLIN, .revents = 1 }; //mozno nebude bavit 0pri revents
    if (context->is_server) {
        if ((context->listen_fd = tcp_listener(context->server_ip_or_name, context->server_port)) ==
            INVSCK) { //napoji socket na eth0
            printf("2. %d\n",WSAGetLastError());
            perror("Unable to set up a TCP server");
            return -1;
        }
        context->fds[POLLFD_LISTENER] = (struct pollfd){
            .fd     = context->listen_fd,
            .events = POLLIN,
        };
    }
    if (!context->is_server && client_reconnect(context) != 0) {
        fprintf(stderr, "Unable to connect to server: [%s]\n", strerror(errno));
        return -1;
    }
    while (event_loop(context) == 0)
        ;
    return 0;
}
//#ifndef _WIN32
static int load_key_file(Context *context, const char *file)
{
    unsigned char key[32];
    int           fd;
#ifndef _WIN32
    if ((fd = open(file, O_RDONLY)) == -1) {
        return -1;
    }
    if (safe_read(fd, key, sizeof key, -1) != sizeof key) {
        (void) close(fd);
        return -2;
    }
    uc_state_init(context->uc_kx_st, key, (const unsigned char *) "VPN Key Exchange");
    uc_memzero(key, sizeof key);
    return close(fd);
#else
    if ((fd = w_open(file, O_RDONLY)) == -1) {
        return -1;
    }
    if (w_read_file(fd, key, sizeof key) != sizeof key) {
        (void) w_close(fd);
        return -2;
    }
    uc_state_init(context->uc_kx_st, key, (const unsigned char *) "VPN Key Exchange");
    uc_memzero(key, sizeof key);
    return w_close(fd);
#endif

}

__attribute__((noreturn)) static void usage(void)
{
    puts("DSVPN " VERSION_STRING
         " usage:\n"
         "\n"
         "dsvpn\t\"server\"\n\t<key file>\n\t<vpn server ip or name>|\"auto\"\n\t<vpn "
         "server port>|\"auto\"\n\t<tun interface>|\"auto\"\n\t<local tun "
         "ip>|\"auto\"\n\t<remote tun ip>\"auto\"\n\t<external ip>|\"auto\""
         "\n\n"
         "dsvpn\t\"client\"\n\t<key file>\n\t<vpn server ip or name>\n\t<vpn server "
         "port>|\"auto\"\n\t<tun interface>|\"auto\"\n\t<local tun "
         "ip>|\"auto\"\n\t<remote tun ip>|\"auto\"\n\t<gateway ip>|\"auto\"\n\n"
         "Example:\n\n[server]\n\tdd if=/dev/urandom of=vpn.key count=1 bs=32\t# create key\n"
         "\tbase64 < vpn.key\t\t# copy key as a string\n\tsudo ./dsvpn server vpn.key\t# listen on "
         "443\n\n[client]\n\techo ohKD...W4= | base64 --decode > vpn.key\t# paste key\n"
         "\tsudo ./dsvpn client vpn.key 34.216.127.34\n");
    exit(254);
}
static void get_tun6_addresses(Context *context)
{
    static char local_tun_ip6[40], remote_tun_ip6[40];

    snprintf(local_tun_ip6, sizeof local_tun_ip6, "64:ff9b::%s", context->local_tun_ip);
    snprintf(remote_tun_ip6, sizeof remote_tun_ip6, "64:ff9b::%s", context->remote_tun_ip);
    context->local_tun_ip6  = local_tun_ip6;
    context->remote_tun_ip6 = remote_tun_ip6;
}

static int resolve_ip(char *ip, size_t sizeof_ip, const char *ip_or_name)
{
    struct addrinfo hints, *res;
    int             eai;

    memset(&hints, 0, sizeof hints);
    hints.ai_flags    = 0;              //zadne vlajocky
    hints.ai_family   = AF_UNSPEC;      //af family
    hints.ai_socktype = SOCK_STREAM;    //tcpsocket
    hints.ai_addr     = NULL;           //zadna priradena add 
    //hladaa ip, ktora splna konfig hints a nie je nan ziadna sluzba, ulozi do res vysledok
    if ((eai = getaddrinfo(ip_or_name, NULL, &hints, &res)) != 0 ||
        (res->ai_family != AF_INET && res->ai_family != AF_INET6) ||
        (eai = getnameinfo(res->ai_addr, res->ai_addrlen, ip, (socklen_t) sizeof_ip, NULL, 0,
                           NI_NUMERICHOST | NI_NUMERICSERV)) != 0) {
        fprintf(stderr, "Unable to resolve [%s]: [%s]\n", ip_or_name, gai_strerror(eai));
        return -1;
    }//naslo taky server s takymi parametrami
    puts("resolveip ok");
    return 0;
}

int main(int argc, char *argv[])
{
    /*
        "args": ["client", "C:/Users/marro/Desktop/xy/m.key", "192.168.88.33", "2340", "auto", "10.8.1.2", "10.8.1.1"],
        "args": ["server", "C:/Users/DP_Win/Desktop/xy/m.key", "auto", "2340", "auto", "10.8.1.2", "10.8.1.1"],
    */

    Context     context;
    const char *ext_gw_ip;

#ifdef _WIN32
    WSADATA wsa;
    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2,2), &wsa) != 0) {
        printf("WSAStartup failed. Error Code : %d", WSAGetLastError());
        return 1;
    }
#endif

    if (argc < 3) {
        usage();
    }
    memset(&context, 0, sizeof context);
    context.is_server = strcmp(argv[1], "server") == 0;

    if (load_key_file(&context, argv[2]) != 0) {
        fprintf(stderr, "Unable to load the key file [%s]\n", argv[2]);
        return 1;
    }

    context.server_ip_or_name = (argc <= 3 || strcmp(argv[3], "auto") == 0) ? NULL : argv[3];
    if (context.server_ip_or_name == NULL && !context.is_server) {
        usage();
    }
    context.server_port    = (argc <= 4 || strcmp(argv[4], "auto") == 0) ? DEFAULT_PORT : argv[4];
    context.wanted_if_name = (argc <= 5 || strcmp(argv[5], "auto") == 0) ? NULL : argv[5];
    context.local_tun_ip   = (argc <= 6 || strcmp(argv[6], "auto") == 0)
                               ? (context.is_server ? DEFAULT_SERVER_IP : DEFAULT_CLIENT_IP)
                               : argv[6];
    context.remote_tun_ip = (argc <= 7 || strcmp(argv[7], "auto") == 0)
                                ? (context.is_server ? DEFAULT_CLIENT_IP : DEFAULT_SERVER_IP)
                                : argv[7];
    context.wanted_ext_gw_ip = (argc <= 8 || strcmp(argv[8], "auto") == 0) ? NULL : argv[8];
    ext_gw_ip = context.wanted_ext_gw_ip ? context.wanted_ext_gw_ip : get_default_gw_ip();
    snprintf(context.ext_gw_ip, sizeof context.ext_gw_ip, "%s", ext_gw_ip == NULL ? "" : ext_gw_ip);
    if (ext_gw_ip == NULL && !context.is_server) {
        fprintf(stderr, "Unable to automatically determine the gateway IP\n");
        return 1;
    }
    if ((context.ext_if_name = get_default_ext_if_name()) == NULL && context.is_server) { //pozri co tu je
        fprintf(stderr, "Unable to automatically determine the external interface\n");
        return 1;
    }
    get_tun6_addresses(&context);
    
    #ifndef _WIN32 //wintun ma na hodnotu 0xFFFF = 65535
    context.tun_fd = tun_create(context.if_name, context.wanted_if_name);
    if (context.tun_fd == -1) {
        perror("tun device creation");
        return 1;
    }
    printf("Interface: [%s]\n", context.if_name);

    if (tun_set_mtu(context.if_name, DEFAULT_MTU) != 0) {
        perror("mtu");
    }
    #else
    if (wtunInit(&context)!=0){
        getchar();
        puts("wtunInit error");
        return 1;
    }
    #endif
    #ifdef __OpenBSD__
    pledge("stdio proc exec dns inet", NULL);
    #endif

    context.firewall_rules_set = -1;
    if (context.server_ip_or_name != NULL &&    //len ak je client tak server_ip_or name nie je null
        resolve_ip(context.server_ip, sizeof context.server_ip, context.server_ip_or_name) != 0) {
        firewall_rules(&context, 0, 1); //ked nenajde server tak resetuje pravidla
        return 1;
    }
    if (context.is_server) {
        if (firewall_rules(&context, 1, 0) != 0) {  //set pravidiel 
        #ifdef __OpenBSD__
            printf("\nAdd the following rule to /etc/pf.conf:\npass out from %s nat-to egress\n\n",
               context.remote_tun_ip);
        #endif
        }
    } else {
        firewall_rules(&context, 0, 1); //reset pravidiel
    }
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    if (doit(&context) != 0) {
        return -1;
    }
    firewall_rules(&context, 0, 0);
    puts("Done.");

    #ifdef _WIN32
    w_cleanUp(&context);
    #endif

    return 0;
}
