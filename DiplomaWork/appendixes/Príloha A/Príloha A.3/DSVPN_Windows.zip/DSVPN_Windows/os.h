#ifndef os_H
#define os_H 1

#include "vpn.h"
ssize_t safe_read(const SCK fd, void *const buf_, size_t count, const int timeout);

ssize_t safe_write(const SCK fd, const void *const buf_, size_t count, const int timeout);

ssize_t safe_read_partial(const SCK fd, void *const buf_, const size_t max_count);

ssize_t safe_write_partial(const SCK fd, void *const buf_, const size_t max_count);

ssize_t tun_read(SCK fd, void *data, size_t size);

ssize_t tun_write(SCK fd, const void *data, size_t size);

typedef struct Cmds {
    const char *const *set;
    const char *const *unset;
} Cmds;

int tcp_opts(SCK fd);

Cmds firewall_rules_cmds(int is_server);

int shell_cmd(const char *substs[][2], const char *args_str, int silent);

const char *get_default_gw_ip(void);

const char *get_default_ext_if_name(void);

int tun_create(char if_name[IFNAMSIZ], const char *wanted_name);

int tun_set_mtu(const char *if_name, int mtu);

#ifdef _WIN32
int SCK_close(SCK fd);
int w_open(const char *filename, int flag);
int w_read(int file, unsigned char *buf, size_t count);
int w_close(int file);
ssize_t w_read_file(const int fd, void *const buf_, size_t count);
ssize_t w_safe_read(const SOCKET fd, void *const buf_, size_t count, const int timeout);
ssize_t w_safe_write(const SOCKET fd, const void *const buf_, size_t count, const int timeout);
ssize_t w_safe_read_partial(const SOCKET fd, void *const buf_, const size_t max_count);
ssize_t w_safe_write_partial(const SOCKET fd, void *const buf_, const size_t max_count);
#endif
#endif

